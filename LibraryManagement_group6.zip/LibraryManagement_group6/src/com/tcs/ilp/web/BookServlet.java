package com.tcs.ilp.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.tcs.ilp.bean.Book;
import com.tcs.ilp.service.BookService;

public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public BookServlet() {
        super();
    }
    
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		int count=1;
		String action=req.getParameter("action");
		PrintWriter pw=res.getWriter();
		BookService service=new BookService();
		if(action.equals("Submit")){
			
			
			String category=req.getParameter("category");
			String bookName=req.getParameter("bname");
			String author=req.getParameter("author");
			double price=Double.parseDouble(req.getParameter("price"));
			String status=req.getParameter("status");
			
			Book book=new Book(0, category, bookName, author, price, status);
			
			Book b=service.addBook(book);
			if(b!=null){
				pw.write("<p align='center' style='color:green'>Book Added Successfully!</p><br>");
				pw.write("<p align='center' style='color:green'>Book number generated:-"+b.getBookId()+"</p><br>");
				pw.write("<p align='center'><a href='home.jsp'>Menu</a></p>");
			}
			else{
				pw.write("<p align='center' style='color:red'>Error while adding Book!</p><br>");
				pw.write("<p align='center' style='color:red'>Please check your deatails...</p><br>");
				pw.write("<p align='center'><a href='home.jsp'>Menu</a></p>");
			}
		}
		
		if(action.equals("Search")){
			String bookName = req.getParameter("bName");
			//pw.print(bookName);
			String S2=null;
			BookService serv = new BookService();
			try {
				
				Book bb = serv.searchUser(bookName);
				if(bb.getAuthor()==null)
					count=0;
				if(count!=0){
				if(bb.getStatus().equals("Available")){
					S2 = "Unavailable";
				}
				else{
					 S2 = "Available";
				}
				
				req.setAttribute("ID", bb.getBookId());
				req.setAttribute("C1", bb.getCategory());
				req.setAttribute("N1", bb.getBookName());
				req.setAttribute("A1", bb.getAuthor());
				req.setAttribute("P1", bb.getPrice());
				req.setAttribute("S1", bb.getStatus());
				req.setAttribute("S3", S2);}
				if(count==1){
				RequestDispatcher dispatcher = req.getRequestDispatcher("searchResult.jsp");  
				   if (dispatcher != null){  
				      dispatcher.forward(req, res);  
				   } }	
				else{
					req.setAttribute("Msg", "BOOK NOT FOUND IN LIBRARY");
					RequestDispatcher dispatcher = req.getRequestDispatcher("failure.jsp");  
					   if (dispatcher != null){  
					      dispatcher.forward(req, res);  
				}
			}} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		}
		
		if(action.equals("Update")){
			String Status = req.getParameter("option");
			String ID = req.getParameter("ID");
						
			BookService serv = new BookService();
			
			int a = serv.updateBook(ID, Status);
			
			if(a>0){
				RequestDispatcher dispatcher = req.getRequestDispatcher("home.jsp");
				if (dispatcher != null){  
				      dispatcher.forward(req, res);  
				   }
			}
			else{
				req.setAttribute("Msg", "Update Failed");
				RequestDispatcher dispatcher = req.getRequestDispatcher("failure.jsp");  
				   if (dispatcher != null){  
				      dispatcher.forward(req, res);  
				   }
				
			}
			
		}
		
		
	
		
		if(action.equals("Delete")){
			
			String bid=req.getParameter("BookID");
			pw.print(bid);
			int val=service.delete(bid);
			if(val>0){
				RequestDispatcher dispatcher=req.getRequestDispatcher("ViewList.jsp");
			dispatcher.forward(req, res);
			}
		}
	}
	
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}

}
