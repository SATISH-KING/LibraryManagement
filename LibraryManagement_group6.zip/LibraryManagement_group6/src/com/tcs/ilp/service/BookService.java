package com.tcs.ilp.service;

import java.sql.SQLException;



import com.tcs.ilp.bean.Book;
import com.tcs.ilp.dao.BookDao;

public class BookService {

	public Book addBook(Book book){
		BookDao dao=new BookDao();
		return dao.addBook(book);
	}

	public int delete(String bid) {
		BookDao dao=new BookDao();
		return dao.deleteRow(bid);
	}

	
	public Book searchUser(String b) throws SQLException {
		BookDao dao=new BookDao();
		return dao.searchBook(b);
	}
	
	public int updateBook(String b_id,String status){
		BookDao dd = new BookDao();
		return dd.updateBook(b_id, status);
	}
	
	
}

