package com.tcs.ilp.bean;

public class Book {
	private long BookId;
	private String Category;
	private String BookName;
	private String Author;
	private double Price;
	private String Status;
	public Book(long bookId, String category, String bookName, String author,
			double price, String status) {
		super();
		BookId = bookId;
		Category = category;
		BookName = bookName;
		Author = author;
		Price = price;
		Status = status;
	}
	public Book() {
		// TODO Auto-generated constructor stub
	}
	public long getBookId() {
		return BookId;
	}
	public void setBookId(long bookId) {
		BookId = bookId;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	

}
