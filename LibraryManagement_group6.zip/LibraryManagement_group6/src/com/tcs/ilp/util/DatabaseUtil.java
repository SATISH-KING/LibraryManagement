package com.tcs.ilp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {
	
	private static final String URL = "jdbc:oracle:thin:@172.26.48.53:1521:ORAJAVADB";
	private static final String DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
	private static final String USERNAME = "KOL1617_KOL03_KJA05_DEV";
	private static final String PASSWORD = "tcskol03";

	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(DRIVER_NAME);
			con = DriverManager.getConnection(URL, USERNAME, PASSWORD);

		}
		catch (ClassNotFoundException e) {e.printStackTrace();}
		catch (SQLException e) {e.printStackTrace();}
		return con;
	}
	

	public static void closeConnection(Connection con) {

		if (con != null) {
			try {con.close();}
			catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	
	public static void closeStatement(Statement st) {

		if (st != null) {
			try {st.close();}
			catch (SQLException e) {e.printStackTrace();}
		}
	}
	

	public static void closePreparedStatement(PreparedStatement ps) {

		if (ps != null) {
			try {ps.close();}
			catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static void closeResultSet(ResultSet rs) {

		if (rs != null) {
			try {rs.close();}
			catch (SQLException e) {e.printStackTrace();}
		}
	}



}
