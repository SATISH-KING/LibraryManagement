package com.tcs.ilp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import com.tcs.ilp.bean.Book;
import com.tcs.ilp.util.DatabaseUtil;

public class BookDao {
	
	public long nextBookId() {
		Connection con=null;
		PreparedStatement ps=null;
		Book b=null;
		long seq=0;
		try{
			con=DatabaseUtil.getConnection();
			ps=con.prepareStatement("SELECT book_seq_1291484.nextval FROM DUAL");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				seq=rs.getLong(1);
			}
		}
		catch(SQLException e){e.printStackTrace();}
		finally{
			DatabaseUtil.closePreparedStatement(ps);
			DatabaseUtil.closeConnection(con);
		}
		return seq;
	}
	
	public Book addBook(Book book){
		Connection con=null;
		PreparedStatement ps=null;
		Book b=null;
		try{
			con=DatabaseUtil.getConnection();
			ps=con.prepareStatement("INSERT INTO TBL_BOOK_1291484 VALUES(?,?,?,?,?,?)");
			book.setBookId(nextBookId());
			ps.setLong(1, book.getBookId());
			ps.setString(2, book.getCategory());
			ps.setString(3, book.getBookName());
			ps.setString(4, book.getAuthor());
			ps.setDouble(5, book.getPrice());
			ps.setString(6, book.getStatus());
			if(ps.executeUpdate()>0){
				b=book;
			}
		}
		catch(SQLException e){e.printStackTrace();}
		finally{
			DatabaseUtil.closePreparedStatement(ps);
			DatabaseUtil.closeConnection(con);
		}
		return b;
	}

	public int deleteRow(String bid) {
		Connection con=null;
		PreparedStatement ps=null;
		int x=0;
		try{
			con=DatabaseUtil.getConnection();
			ps=con.prepareStatement("DELETE FROM TBL_BOOK_1291484 WHERE BOOKID = ?");
			ps.setString(1, bid);
			x=ps.executeUpdate();
			
		}
		catch(SQLException e){e.printStackTrace();}
		finally{
			DatabaseUtil.closePreparedStatement(ps);
			DatabaseUtil.closeConnection(con);
		}
		return x;
	}

	public Book searchBook(String b_name) throws SQLException{
		Book b = new Book();
		ResultSet rs=null;
		//System.out.println(b_name);
		Connection con = DatabaseUtil.getConnection();
		b_name="%"+b_name+"%";
		
		PreparedStatement st =con.prepareStatement("SELECT * FROM TBL_BOOK_1291484 WHERE BookName LIKE ?");
		st.setString(1, b_name);
		rs = st.executeQuery();
		while (rs.next()){
			b.setBookId(rs.getLong(1));
			b.setCategory(rs.getString(2));
			b.setBookName(rs.getString(3));
			b.setAuthor(rs.getString(4));
			b.setPrice(rs.getDouble(5));
			b.setStatus(rs.getString(6));
		}
		rs.close();
		st.close();
		con.close();
		return b;	
	}
	
	
	public int updateBook(String b_id,String status){
		Connection con = DatabaseUtil.getConnection();
		System.out.println(b_id);
		System.out.println(status);
		try {
			Statement st = con.createStatement();
			int a=st.executeUpdate("update TBL_BOOK_1291484 set STATUS ='" +status+ "' where BOOKID ='" +b_id+ "'");
			
			st.close();
			con.close();
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
		
	}	
	
	
}
